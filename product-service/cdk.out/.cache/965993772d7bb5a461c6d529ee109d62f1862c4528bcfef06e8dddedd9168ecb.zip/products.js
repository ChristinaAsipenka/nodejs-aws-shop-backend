const products = [
    {"id": "1", "title": "Product_1", "price":"10"},
    {"id": "2", "title": "Product_2", "price":"15"},
    {"id": "3", "title": "Product_3", "price":"17"},
];
module.exports = products;