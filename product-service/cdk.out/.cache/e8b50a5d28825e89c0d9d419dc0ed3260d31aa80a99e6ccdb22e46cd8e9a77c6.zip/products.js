const myArray = [
    {"id": "1", "name": "Product_1", "price":"10"},
    {"id": "2", "name": "Product_2", "price":"15"},
    {"id": "3", "name": "Product_3", "price":"17"},
];
module.exports = myArray;