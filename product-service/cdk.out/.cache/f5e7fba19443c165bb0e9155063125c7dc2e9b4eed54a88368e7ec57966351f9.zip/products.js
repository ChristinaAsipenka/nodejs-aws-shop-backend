const products = [
    {
        id: "1", 
        title: "Product_1", 
        price:10,
        description: "Short Product Description1"
    },
    {
        id: "2",
        title: "Product_2",
        price:15,
        description: "Short Product Description2"
    },
    {
        id: "3",
        title: "Product_3",
        price:17,
        description: "Short Product Description3"
    },
];
module.exports = products;